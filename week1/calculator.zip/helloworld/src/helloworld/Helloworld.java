package helloworld;

public class Helloworld {
    
    public void main() {
        System.out.println(helloWorld());
    }
    
    public static String helloWorld() {
        return "Hello World!";
    }

}